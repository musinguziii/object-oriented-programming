class Cars:
    # Class variable
    NumOfWheels = 4

    def __init__(self, color, model, price):
        # Instance variables
        self.color = color
        self.model = model
        self.price = price

# Creating two Car objects
car1 = Cars("Black", "Tesla", "50000$")
car2 = Cars("Grey", "BMW", "80000$")

# Accessing the  class variable
print(car1.NumOfWheels)  
print(car2.NumOfWheels)  

# Accessing instance variables
print(car1.price)  
print(car2.price)  
print(car1.color)
print(car2.color)
print(car1.model)
print(car2.model)
 