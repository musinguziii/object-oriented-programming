class University:
    def __init__(self, name, location, Email, contact, branches = 1):
        self.name = name
        self.location = location
        self.Email = Email
        self.contact = contact
        self.branches = branches

    def __str__(self):
        return(f" {self.name} is located in {self.location}, It's email and contact are {self.Email} , {self.contact} , it has  {self.branches} branches")

ucu = University("ucu",  "Mukono", "ucu@gmail.com", "0300512764", 6)


print(ucu)
