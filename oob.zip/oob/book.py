class Book:
    def _init_(self, title, author, genre):
        self.title = title
        self.author = author
        self.genre = genre
