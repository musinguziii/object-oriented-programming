class Airbnb:
    def _init_(self, address, room_no, price,):
        self.address = address
        self.room_no = room_no
        self.price = price

        