class Car:
    def _init_(self, company, model, year, color):
        self.company = company
        self.model = model
        self.year = year
        self.color = color

