# Phone class Example
class Phone:
    #constructor to initialize the phone object
    def __init__(self, brand, model, price):
        self.brand = brand
        self.model = model
        self.price = price

    #method to  display the phone details
    def display(self):
        print("brand:", self.brand)
        print("model:", self.model)
        print("price:", self.price)

     #method to call
    def call(self,number):
        print("calling", number)   


        