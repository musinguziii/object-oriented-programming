class Intern:
    def _init_(self, name, intern_id, department, salary):
        self.name = name
        self.intern_id = intern_id
        self.department = department
        self.salary = salary
